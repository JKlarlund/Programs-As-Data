# Weekly Feedback

This folder contains feedback from the weekly assignments.