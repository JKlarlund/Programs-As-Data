import java.util.HashMap;

abstract class Expr {
    @Override
    public String toString(){
        return "";
    }

    abstract int eval(HashMap<String, Integer> env);
    abstract Expr simplify();
}

class CstI extends Expr{
    int value;
    CstI(int v){
        value = v;
    }

    @Override
    public String toString(){
        return Integer.toString(value);
    }

    int eval(HashMap<String, Integer> env){
        return value;
    }

    Expr simplify(){
        return this;
    }



}

class Var extends Expr{
    String name;
    Var(String n){
        name = n;
    }
    @Override
    public String toString(){
        return name;
    }

    int eval(HashMap<String, Integer> env){
        return env.get(name);
    }

    Expr simplify(){
        return this;
    }
}

abstract class Binop extends Expr{}

class Add extends Binop{
    Expr left;
    Expr right;
    Add(Expr e1, Expr e2){
        this.left = e1;
        this.right = e2;
    }

    @Override
    public String toString(){
        return "(" + left.toString() + " + " + right.toString() + ")";
    }

    int eval(HashMap<String, Integer> env){
        return left.eval(env) + right.eval(env);
    }

    Expr simplify() {
        Expr l = left.simplify();
        Expr r = right.simplify();

        if (r instanceof CstI && l instanceof CstI) {
            return new CstI(((CstI) l).value + ((CstI) r).value);
        } else if (r instanceof CstI) {
            if (((CstI) r).value == 0) {
                return l;
            }
        } else if (l instanceof CstI) {
            if (((CstI) l).value == 0) {
                return r;
            }
        }

        return new Add(l, r);

    }


}

class Sub extends Binop{
    Expr left;
    Expr right;
    Sub(Expr e1, Expr e2){
        this.left = e1;
        this.right = e2;
    }
    @Override
    public String toString(){
        return "(" + left.toString() + " - " + right.toString() + ")";
    }

    int eval(HashMap<String, Integer> env){
        return left.eval(env) - right.eval(env);
    }

    Expr simplify(){
        Expr l = left.simplify();
        Expr r = right.simplify();

        if (l instanceof CstI && r instanceof CstI) {
            return new CstI(((CstI) l).value - ((CstI) r).value);
        } else if (r instanceof CstI) {
            if (((CstI) r).value == 0) {
                return l;
            }
        } else if (l instanceof CstI) {
            if (((CstI) l).value == 0) {
                return new Mul(new CstI(-1), r);
            }
        } else if (l.equals(r)) {
            return new CstI(0);
        }
        return new Sub(l, r);
    }
}

class Mul extends Binop{
    Expr left;
    Expr right;
    Mul(Expr e1, Expr e2){
        this.left = e1;
        this.right = e2;
    }
    @Override
    public String toString(){
        return "(" + left.toString() + " * " + right.toString() + ")";
    }

    int eval(HashMap<String, Integer> env){
        return left.eval(env) * right.eval(env);
    }

    Expr simplify(){
        Expr l = left.simplify();
        Expr r = right.simplify();

        if (l instanceof CstI && r instanceof CstI) {
            return new CstI(((CstI) l).value * ((CstI) r).value);
        }
        else if (l.equals(r)) {
            return new Exp(l, new CstI(2));
        }
        else if (l instanceof CstI && ((CstI) l).value == 0) {
            return new CstI(0);
        }
        else if (r instanceof CstI && ((CstI) r).value == 0) {
            return new CstI(0);
        }
        else if (l instanceof CstI && ((CstI) l).value == 1) {
            return r;
        }
        else if (r instanceof CstI && ((CstI) r).value == 1) {
            return l;
        }
        return new Mul(l, r);
    }
}

class Mod extends Binop{
    Expr left;
    Expr right;
    Mod(Expr e1, Expr e2) {
        this.left = e1;
        this.right = e2;
    }
    @Override
    public String toString(){
        return "(" + left.toString() + " % " + right.toString() + ")";
    }
    int eval(HashMap<String, Integer> env){
        return left.eval(env) % right.eval(env);
    }

    Expr simplify(){
        Expr l = left.simplify();
        Expr r = right.simplify();

        if (l instanceof CstI && r instanceof CstI) {
            return new CstI(((CstI) l).value % ((CstI) r).value);
        }
        else if (r instanceof CstI && ((CstI) r).value == 1) {
            return new CstI(0);
        }
        else if (left.simplify() == right.simplify()){
            return new CstI(0);
        }
        return new Mod(l, r);
    }
}

class Div extends Binop{
    Expr left;
    Expr right;
    Div(Expr e1, Expr e2){
        this.left = e1;
        this.right = e2;
    }
    @Override
    public String toString(){
        return "(" + left.toString() + " / " + right.toString() + ")";
    }

    int eval(HashMap<String, Integer> env){
        return left.eval(env) / right.eval(env);
    }

    Expr simplify(){
        Expr l = left.simplify();
        Expr r = right.simplify();
        if(r instanceof CstI && ((CstI) r).value == 1){
            return l;
        }
        else if(r instanceof CstI && ((CstI) r).value == 0){
            return new CstI(0);
        }
        else{
            return new Div(l, r);
        }
    }

}

class Exp extends Binop{
    Expr left;
    Expr right;
    Exp(Expr e1, Expr e2){
        this.left = e1;
        this.right = e2;
    }
    @Override
    public String toString(){
        return "(" + left.toString() + "^" + right.toString() + ")";
    }

    int eval(HashMap<String, Integer> env){
        return (int) Math.pow(left.eval(env), right.eval(env));
    }

    Expr simplify(){
        Expr l = left.simplify();
        Expr r = right.simplify();
        if(l instanceof CstI && r instanceof CstI){
            return new CstI((int) Math.pow(((CstI) l).value, ((CstI) r).value));
        }
        else if(l instanceof CstI) {
            int val = ((CstI) l).value;
            if (val == 0) {
                return new CstI(0);
            } else if (val == 1) {
                return new CstI(1);
            }
        }

        else if (r instanceof CstI && ((CstI) r).value == 0){
            return new CstI(1);
        }
        return new Exp(l, r);
    }

}


